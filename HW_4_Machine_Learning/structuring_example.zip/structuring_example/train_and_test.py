import numpy as np
import sys
import load_data
import decision_tree as dt

"""
This is the main python method that will be run.
You should determine what sort of command line arguments
you want to use. But in this module you will need to 
1) initialize your classifier and its params 
2) load training/test data 
3) train the algorithm
4) test it and output the desired statistics.
"""

if sys.argv[1] == 'decision_tree':
    # the entire decision tree can be represented by its root node
    # so the parameters for this classifier are simply the root node
    decision_tree = Classifer('decision_tree', root_node = dt.Node())

# now you still need to pick the data to use, train the tree, and then test